Important changes to the competition!!!

1. Images are now 32x32 resolution

2. In the test set, there is now a novel superclass in addition to a novel subclass. 
   Images that belong to a novel superclass will automatically belong to a novel subclass.
   Images in seen superclasses can still belong to either a seen subclass or a novel subclass. 

The annotation formatting of the dataset is still the same, however the class mapping files
as well as the training/testing data files have changed. Please make sure you are using the
updated version!